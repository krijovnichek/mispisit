create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public."Телефоны" DROP CONSTRAINT "Телефоны_кодТелефонаТип_fkey";
ALTER TABLE ONLY public."ТелефонныйСправочник" DROP CONSTRAINT "ТелефонныйСправоч_кодТелефона_fkey";
ALTER TABLE ONLY public."ТелефонныйСправочник" DROP CONSTRAINT "ТелефонныйСправ_кодСотрудника_fkey";
ALTER TABLE ONLY public."Сотрудники" DROP CONSTRAINT "Сотрудники_кодПодразделения_fkey";
ALTER TABLE ONLY public."Подразделения" DROP CONSTRAINT "Подразделения_кодГоловногоПод_fkey";
ALTER TABLE ONLY public."Телефоны" DROP CONSTRAINT "Телефоны_pkey";
ALTER TABLE ONLY public."ТелефоновТипы" DROP CONSTRAINT "ТелефоновТипы_название_key";
ALTER TABLE ONLY public."ТелефоновТипы" DROP CONSTRAINT "ТелефоновТипы_pkey";
ALTER TABLE ONLY public."ТелефонныйСправочник" DROP CONSTRAINT "ТелефонныйСправочник_pkey";
ALTER TABLE ONLY public."ТелефонныйСправочник" DROP CONSTRAINT "ТелефонныйСправочн_кодТелефона_key";
ALTER TABLE ONLY public."Сотрудники" DROP CONSTRAINT "Сотрудники_pkey";
ALTER TABLE ONLY public."Подразделения" DROP CONSTRAINT "Подразделения_название_key";
ALTER TABLE ONLY public."Подразделения" DROP CONSTRAINT "Подразделения_pkey";
ALTER TABLE public."Телефоны" ALTER COLUMN "кодТелефона" DROP DEFAULT;
ALTER TABLE public."ТелефоновТипы" ALTER COLUMN "кодТелефонаТип" DROP DEFAULT;
ALTER TABLE public."ТелефонныйСправочник" ALTER COLUMN "кодЗаписи" DROP DEFAULT;
ALTER TABLE public."Подразделения" ALTER COLUMN "кодПодразделения" DROP DEFAULT;
DROP SEQUENCE public."Телефоны_кодТелефона_seq";
DROP TABLE public."Телефоны";
DROP SEQUENCE public."ТелефоновТипы_кодТелефонаТип_seq";
DROP TABLE public."ТелефоновТипы";
DROP SEQUENCE public."ТелефонныйСправочник_кодЗаписи_seq";
DROP TABLE public."ТелефонныйСправочник";
DROP TABLE public."Сотрудники";
DROP SEQUENCE public."Подразделения_кодПодразделения_seq";
DROP TABLE public."Подразделения";
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'Standard public schema';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: Подразделения; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE "Подразделения" (
    "кодПодразделения" integer NOT NULL,
    "название" text,
    "кодГоловногоПодраз" integer
);


ALTER TABLE public."Подразделения" OWNER TO postgres;

--
-- Name: Подразделения_кодПодразделения_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "Подразделения_кодПодразделения_seq"
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public."Подразделения_кодПодразделения_seq" OWNER TO postgres;

--
-- Name: Подразделения_кодПодразделения_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "Подразделения_кодПодразделения_seq" OWNED BY "Подразделения"."кодПодразделения";


--
-- Name: Подразделения_кодПодразделения_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"Подразделения_кодПодразделения_seq"', 12, true);


--
-- Name: Сотрудники; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE "Сотрудники" (
    "кодСотрудника" integer NOT NULL,
    "кодПодразделения" integer,
    "фамилия" text,
    "имя" text,
    "отчество" text
);


ALTER TABLE public."Сотрудники" OWNER TO postgres;

--
-- Name: ТелефонныйСправочник; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE "ТелефонныйСправочник" (
    "кодЗаписи" integer NOT NULL,
    "кодТелефона" integer,
    "кодСотрудника" integer
);


ALTER TABLE public."ТелефонныйСправочник" OWNER TO postgres;

--
-- Name: ТелефонныйСправочник_кодЗаписи_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "ТелефонныйСправочник_кодЗаписи_seq"
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public."ТелефонныйСправочник_кодЗаписи_seq" OWNER TO postgres;

--
-- Name: ТелефонныйСправочник_кодЗаписи_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "ТелефонныйСправочник_кодЗаписи_seq" OWNED BY "ТелефонныйСправочник"."кодЗаписи";


--
-- Name: ТелефонныйСправочник_кодЗаписи_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"ТелефонныйСправочник_кодЗаписи_seq"', 35, true);


--
-- Name: ТелефоновТипы; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE "ТелефоновТипы" (
    "кодТелефонаТип" integer NOT NULL,
    "название" text
);


ALTER TABLE public."ТелефоновТипы" OWNER TO postgres;

--
-- Name: ТелефоновТипы_кодТелефонаТип_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "ТелефоновТипы_кодТелефонаТип_seq"
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public."ТелефоновТипы_кодТелефонаТип_seq" OWNER TO postgres;

--
-- Name: ТелефоновТипы_кодТелефонаТип_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "ТелефоновТипы_кодТелефонаТип_seq" OWNED BY "ТелефоновТипы"."кодТелефонаТип";


--
-- Name: ТелефоновТипы_кодТелефонаТип_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"ТелефоновТипы_кодТелефонаТип_seq"', 1, true);


--
-- Name: Телефоны; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE "Телефоны" (
    "кодТелефона" integer NOT NULL,
    "кодТелефонаТип" integer,
    "номер" text
);


ALTER TABLE public."Телефоны" OWNER TO postgres;

--
-- Name: Телефоны_кодТелефона_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "Телефоны_кодТелефона_seq"
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public."Телефоны_кодТелефона_seq" OWNER TO postgres;

--
-- Name: Телефоны_кодТелефона_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "Телефоны_кодТелефона_seq" OWNED BY "Телефоны"."кодТелефона";


--
-- Name: Телефоны_кодТелефона_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"Телефоны_кодТелефона_seq"', 25, true);


--
-- Name: кодПодразделения; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE "Подразделения" ALTER COLUMN "кодПодразделения" SET DEFAULT nextval('"Подразделения_кодПодразделения_seq"'::regclass);


--
-- Name: кодЗаписи; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE "ТелефонныйСправочник" ALTER COLUMN "кодЗаписи" SET DEFAULT nextval('"ТелефонныйСправочник_кодЗаписи_seq"'::regclass);


--
-- Name: кодТелефонаТип; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE "ТелефоновТипы" ALTER COLUMN "кодТелефонаТип" SET DEFAULT nextval('"ТелефоновТипы_кодТелефонаТип_seq"'::regclass);


--
-- Name: кодТелефона; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE "Телефоны" ALTER COLUMN "кодТелефона" SET DEFAULT nextval('"Телефоны_кодТелефона_seq"'::regclass);


--
-- Data for Name: Подразделения; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "Подразделения" ("кодПодразделения", "название", "кодГоловногоПодраз") FROM stdin;
\.
copy "Подразделения" ("кодПодразделения", "название", "кодГоловногоПодраз")  from '$$PATH$$/1642.dat' ;
--
-- Data for Name: Сотрудники; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "Сотрудники" ("кодСотрудника", "кодПодразделения", "фамилия", "имя", "отчество") FROM stdin;
\.
copy "Сотрудники" ("кодСотрудника", "кодПодразделения", "фамилия", "имя", "отчество")  from '$$PATH$$/1643.dat' ;
--
-- Data for Name: ТелефонныйСправочник; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "ТелефонныйСправочник" ("кодЗаписи", "кодТелефона", "кодСотрудника") FROM stdin;
\.
copy "ТелефонныйСправочник" ("кодЗаписи", "кодТелефона", "кодСотрудника")  from '$$PATH$$/1646.dat' ;
--
-- Data for Name: ТелефоновТипы; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "ТелефоновТипы" ("кодТелефонаТип", "название") FROM stdin;
\.
copy "ТелефоновТипы" ("кодТелефонаТип", "название")  from '$$PATH$$/1644.dat' ;
--
-- Data for Name: Телефоны; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "Телефоны" ("кодТелефона", "кодТелефонаТип", "номер") FROM stdin;
\.
copy "Телефоны" ("кодТелефона", "кодТелефонаТип", "номер")  from '$$PATH$$/1645.dat' ;
--
-- Name: Подразделения_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "Подразделения"
    ADD CONSTRAINT "Подразделения_pkey" PRIMARY KEY ("кодПодразделения");


--
-- Name: Подразделения_название_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "Подразделения"
    ADD CONSTRAINT "Подразделения_название_key" UNIQUE ("название", "кодГоловногоПодраз");


--
-- Name: Сотрудники_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "Сотрудники"
    ADD CONSTRAINT "Сотрудники_pkey" PRIMARY KEY ("кодСотрудника");


--
-- Name: ТелефонныйСправочн_кодТелефона_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "ТелефонныйСправочник"
    ADD CONSTRAINT "ТелефонныйСправочн_кодТелефона_key" UNIQUE ("кодТелефона", "кодСотрудника");


--
-- Name: ТелефонныйСправочник_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "ТелефонныйСправочник"
    ADD CONSTRAINT "ТелефонныйСправочник_pkey" PRIMARY KEY ("кодЗаписи");


--
-- Name: ТелефоновТипы_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "ТелефоновТипы"
    ADD CONSTRAINT "ТелефоновТипы_pkey" PRIMARY KEY ("кодТелефонаТип");


--
-- Name: ТелефоновТипы_название_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "ТелефоновТипы"
    ADD CONSTRAINT "ТелефоновТипы_название_key" UNIQUE ("название");


--
-- Name: Телефоны_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "Телефоны"
    ADD CONSTRAINT "Телефоны_pkey" PRIMARY KEY ("кодТелефона");


--
-- Name: Подразделения_кодГоловногоПод_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Подразделения"
    ADD CONSTRAINT "Подразделения_кодГоловногоПод_fkey" FOREIGN KEY ("кодГоловногоПодраз") REFERENCES "Подразделения"("кодПодразделения");


--
-- Name: Сотрудники_кодПодразделения_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Сотрудники"
    ADD CONSTRAINT "Сотрудники_кодПодразделения_fkey" FOREIGN KEY ("кодПодразделения") REFERENCES "Подразделения"("кодПодразделения");


--
-- Name: ТелефонныйСправ_кодСотрудника_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "ТелефонныйСправочник"
    ADD CONSTRAINT "ТелефонныйСправ_кодСотрудника_fkey" FOREIGN KEY ("кодСотрудника") REFERENCES "Сотрудники"("кодСотрудника");


--
-- Name: ТелефонныйСправоч_кодТелефона_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "ТелефонныйСправочник"
    ADD CONSTRAINT "ТелефонныйСправоч_кодТелефона_fkey" FOREIGN KEY ("кодТелефона") REFERENCES "Телефоны"("кодТелефона");


--
-- Name: Телефоны_кодТелефонаТип_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Телефоны"
    ADD CONSTRAINT "Телефоны_кодТелефонаТип_fkey" FOREIGN KEY ("кодТелефонаТип") REFERENCES "ТелефоновТипы"("кодТелефонаТип");


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

